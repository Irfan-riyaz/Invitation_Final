Put your optional background music here and name it exactly:  nasheed.mp3

Only use a nasheed or instrumental track you are licensed or permitted to publish.
If this file is missing, the website still works and shows a friendly message when
someone taps the music button.

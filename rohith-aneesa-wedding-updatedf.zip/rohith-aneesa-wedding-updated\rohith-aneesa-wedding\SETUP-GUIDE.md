# Rohith & Aneesa Wedding Invitation: Setup Guide

Stack: React + Vite + plain CSS. No backend, no RSVP, no guest data.

## 1. Install the tools
1. Install **Node.js LTS** from https://nodejs.org (accept the defaults).
2. Install **VS Code** from https://code.visualstudio.com.
3. Check it worked. Open a terminal and run `node -v` and `npm -v`. Both should print a version.

## 2. Open this project
You have two options.

**A. Use the zip (easiest).** Unzip `rohith-aneesa-wedding.zip`, then in VS Code choose File > Open Folder and pick the folder. Open the terminal with Ctrl + ` and go to step 3.

**B. Start fresh with Vite.**
```
npm create vite@latest rohith-aneesa-wedding -- --template react
cd rohith-aneesa-wedding
```
Then replace these files with the ones from the zip: `index.html`, `package.json`, `vite.config.js`, `src/App.jsx`, `src/App.css`, `src/index.css`, `src/main.jsx`. Delete the unused `src/assets` folder.

## 3. Install and run
```
npm install
npm run dev
```
Open the address shown (usually http://localhost:5173). To test on your phone, use the "Network" address, with the phone on the same Wi-Fi.

## 4. Add the optional music
Copy a licensed nasheed or instrumental file into `public/` and name it exactly `nasheed.mp3`. Music never plays on page load. It starts only when a guest taps the seal or the Play music button. With no file, the site still works silently; no message or popup appears.

## 5. Things to check before sharing
- **Hijri date:** "10 Sha’ban 1448" was supplied. Confirm it with the family's preferred calendar or the local mosque. My own count puts 17 Jan 2027 around 8 to 10 Sha’ban, depending on moon sighting. To hide it, set `SHOW_HIJRI = false` in `src/App.jsx`.
- **Venue details:** names, dates and map links are in the cards inside `src/App.jsx`; the QR codes are in `src/qr.js` (they point to Google Maps searches for each venue).
- All names, dates, times and addresses live in the `EVENTS` list and `COUPLE` at the top of `src/App.jsx`.

## 6. Test checklist
- [ ] Tap the seal: envelope opens, then the invitation appears.
- [ ] Both names read S. Rohith Riyaz and A. Aneesa Fathima.
- [ ] Nikkah: Sunday 17 Jan 2027, 11:30 AM to 3:00 PM, Srinivasa Mahal, Vanjipalayam Road, Tiruppur – 641 602.
- [ ] Walima: Wednesday 20 Jan 2027, 11:30 AM to 3:00 PM, Aysha Mahal – Hall 1, Palakkad Main Road, Kuniyamuthur, Coimbatore.
- [ ] The invitation keeps the Nikkah and Walima cards matched in size and prints them side by side on A4 landscape.
- [ ] "Get directions" opens Google Maps with the right search.
- [ ] Play / Pause music works with the file present; with no file, the site still works and shows the message.
- [ ] Print / Save invitation shows only the invitation card. Choose "Save as PDF" as the destination.
- [ ] Check on a phone, a tablet and a desktop. Press Tab to see the gold focus outline.
- [ ] No forms or guest data anywhere.
- [ ] `npm run build` finishes without errors.

## 7. Common errors
| Problem | Fix |
|---|---|
| `npm` not recognised | Reinstall Node.js LTS, then reopen VS Code. |
| Blank page | Read the terminal and the browser console (F12). Usually a file name or import typo. |
| Port already in use | Close the other terminal, or Vite will suggest another port. |
| Fonts look plain | Fonts load from Google Fonts. Check your internet connection. |
| Music will not play | File must be `public/nasheed.mp3`. Restart `npm run dev` after adding it. |
| Print shows the whole site | Use Chrome or Edge and press the in-page button, not Ctrl + P. |

## 8. Build and deploy (Netlify)
```
npm run build
```
This creates a `dist` folder.
1. Go to https://app.netlify.com/drop and sign up for free.
2. Drag the **dist** folder onto the page.
3. Netlify gives you a public link like `https://random-name.netlify.app`. You can rename it under Site settings > Change site name.
4. Open the link on your phone and run the checklist again.
5. **Share on WhatsApp:** paste the link into a chat or broadcast list.
6. **Update later:** edit, run `npm run build` again, then in Netlify open Deploys and drag the new `dist` folder onto the deploy area.

A custom domain is optional and can be added later in Netlify under Domain management.

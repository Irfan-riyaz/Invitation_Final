import { useCallback, useEffect, useRef, useState } from 'react'
import { QR } from './qr.js'
import './App.css'

/* ---- Easy-to-edit details ---- */
const AUDIO_SRC = '/nasheed.mp3' // optional, put in /public
const SHOW_HIJRI = true
const MAPS = {
  nikkah: 'Srinivasa Mahal, Vanjipalayam Road, Tiruppur 641602',
  walima: 'Aysha Mahal, Palakkad Main Road, Kuniyamuthur, Coimbatore',
}
// The printed card repeats "you you"; the duplicate is removed here. Re-add it if the family wants it exact.
const DUA_EN = 'May Allah bless you and shower his blessings upon you and you together in goodness.'
const mapsUrl = (q) => `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}`

function Crescent({ className = '' }) {
  return (
    <svg className={className} viewBox="0 0 64 64" aria-hidden="true" focusable="false">
      <g transform="rotate(-12 32 32)">
        <path d="M27 7a25 25 0 1 0 19 47A29 29 0 0 1 27 7z" fill="currentColor" />
        <path d="M40 23l1.6 3.7 4 .4-3 2.7.9 4-3.5-2.1-3.5 2.1.9-4-3-2.7 4-.4z" fill="currentColor" />
      </g>
    </svg>
  )
}

function Divider() {
  return <div className="divider" aria-hidden="true"><span /></div>
}

/* Floral sprig, drawn to echo the leaf-and-blossom corner of the printed card */
const P = [[98, 2], [70, 10], [40, 30], [22, 72]]
const bez = (t, k) => { const m = 1 - t; return m*m*m*P[0][k] + 3*m*m*t*P[1][k] + 3*m*t*t*P[2][k] + t*t*t*P[3][k] }
const tan = (t, k) => { const m = 1 - t; return 3*m*m*(P[1][k]-P[0][k]) + 6*m*t*(P[2][k]-P[1][k]) + 3*t*t*(P[3][k]-P[2][k]) }

function Sprig({ className }) {
  const leaves = [0.1, 0.22, 0.35, 0.48, 0.61, 0.75, 0.9].flatMap((t) =>
    [1, -1].map((s) => {
      const a = (Math.atan2(tan(t, 1), tan(t, 0)) * 180) / Math.PI + 180 + s * 42
      return `translate(${bez(t, 0).toFixed(1)} ${bez(t, 1).toFixed(1)}) rotate(${a.toFixed(0)}) scale(${(1.15 - t * 0.6).toFixed(2)})`
    }),
  )
  return (
    <svg className={`sp ${className}`} viewBox="0 0 100 100" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="1">
      <path d={`M${P[0]} C${P[1]} ${P[2]} ${P[3]}`} />
      {leaves.map((tr, i) => (
        <g key={i} transform={tr}><path d="M0 0C5-6 15-6 20 0C15 6 5 6 0 0zM2 0H17" /></g>
      ))}
      <g transform="translate(90 9)">
        {[0, 72, 144, 216, 288].map((r) => <ellipse key={r} cx="6" rx="5.5" ry="3.2" transform={`rotate(${r})`} />)}
        <circle r="2" fill="currentColor" />
      </g>
    </svg>
  )
}

/* ---- Envelope: tap the seal, gold light sweeps across, then floods bright into the dua ---- */
function Envelope({ onOpen, onDone }) {
  const [stage, setStage] = useState('closed')
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = '' }
  }, [])
  useEffect(() => {
    if (stage !== 'opening') return undefined
    const id = setTimeout(onDone, 3700)
    return () => clearTimeout(id)
  }, [stage, onDone])
  const open = () => { if (stage === 'closed') { setStage('opening'); onOpen() } }
  return (
    <div className={`envelope-screen ${stage}`}>
      <div className="flap flap-left" /><div className="flap flap-right" />
      <div className="flap flap-bottom" /><div className="flap flap-top" />
      <svg className="env-lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <path d="M0 0L50 50L100 0M0 100L50 50L100 100" fill="none" stroke="#e3c58b" strokeOpacity="0.55" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="sweep" /><div className="env-flash" />
      <button className="seal" onClick={open} aria-label="Open the invitation">
        <span className="seal-ring" />
        <span className="seal-face"><Crescent className="seal-moon" /><span className="seal-letters">R &amp; A</span></span>
      </button>
      <p className="env-caption">Tap the seal to open</p>
    </div>
  )
}

/* ---- One invitation card (both share this, so they are always the same size) ---- */
function Card({ k, label, children }) {
  const q = QR[k]
  return (
    <article className="card" aria-label={label}>
      <Sprig className="sp-tr" /><Sprig className="sp-bl" />
      <div className="card-body">
        {children}
        <div className="loc">
          <svg className="loc-q" viewBox={`-2 -2 ${q.n + 4} ${q.n + 4}`} role="img" aria-label={`QR code: ${label} location`}>
            <rect x="-2" y="-2" width={q.n + 4} height={q.n + 4} fill="#fff" /><path d={q.d} />
          </svg>
          <div>
            <span className="loc-k">Scan for location</span>
            <a className="loc-link" href={mapsUrl(MAPS[k])} target="_blank" rel="noopener noreferrer">Get directions</a>
          </div>
        </div>
      </div>
    </article>
  )
}

export default function App() {
  const audioRef = useRef(null)
  const [envelopeOpen, setEnvelopeOpen] = useState(false)
  const [showEnvelope, setShowEnvelope] = useState(true)
  const [playing, setPlaying] = useState(false)

  const playMusic = useCallback(async () => {
    try { await audioRef.current?.play() } catch { setPlaying(false) }
  }, [])
  const toggleMusic = () => (audioRef.current?.paused ? playMusic() : audioRef.current?.pause())
  const handleOpen = () => { setEnvelopeOpen(true); playMusic() }
  const handleDone = useCallback(() => setShowEnvelope(false), [])

  return (
    <div className={`app ${envelopeOpen ? 'revealed' : ''}`}>
      <audio ref={audioRef} src={AUDIO_SRC} loop preload="none" onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)}
        onError={() => setPlaying(false)} />
      {showEnvelope && <Envelope onOpen={handleOpen} onDone={handleDone} />}

      {/* Page 1: Dua */}
      <header className="dua" id="top">
        <div className="dua-frame">
          <Crescent className="dua-moon rv" />
          <p className="arabic rv rv2" lang="ar" dir="rtl">بَارَكَ اللَّهُ لَكَ وَبَارَكَ عَلَيْكَ وَجَمَعَ بَيْنَكُمَا فِي خَيْرٍ</p>
          <p className="dua-tr rv rv3">“Baraka llahu Laka wa baraka Alaika<br />Wa jamaah baina kuma fee khai”</p>
          <p className="dua-en rv rv3">{DUA_EN}</p>
          <a className="btn rv rv4" href="#invitation">View invitation</a>
        </div>
      </header>

      {/* Page 2: Nikkah + Walima, side by side */}
      <section className="invite" id="invitation" aria-labelledby="inv-title">
        <h2 id="inv-title">Nikkah &amp; Walima Invitation</h2>
        <div className="sheet" id="invite-sheet">
          <Card k="nikkah" label="Nikkah">
            <p className="cs">In the name of Allah, the most beneficent and merciful</p>
            <h3 className="script ctitle">Nikkah Invitation</h3>
            <p className="cb">Mr. S. Shajahan &amp; Mrs. S. Shahitha</p>
            <p className="cs">No.14, Green Park, Podanur, Coimbatore - 641 023 · Ph: 97894 72273</p>
            <p className="gap">With the blessings of Allah, we are delighted to invite you to the Nikkah Ceremony of our beloved son</p>
            <p className="script cname gap">S. Rohith Riyaz <span className="cs">B.Sc.(CSA),</span></p>
            <p className="cs">(Ranaco Moldwell Pvt. Ltd., Group of companies)<br />Paternal Grand S/o. Late. S. Shahabuddin, Udumalai<br />Maternal Grand S/o. Late. A.R. Haroon Basha, Udumalai</p>
            <p className="gap">with</p>
            <p className="script cname">A. Aneesa Fathima <span className="cs">BBA.(CA), MBA</span></p>
            <p>D/o. Mr. M. Aslam &amp; Mrs. S. Abitha Begum</p>
            <p className="cs">(Peace Garments)<br />Paternal Grand D/o. Mr. &amp; Mrs. Haji Janab G. Mohamed Ghouse Sahib (Mysore Bhai)<br />Maternal Grand D/o. Mr &amp; Mrs. Haji Janab A.K. Sarfudeen Sahib (N.M.H Hosiery)</p>
            <p className="gap">On Sunday, 17th January 2027{SHOW_HIJRI && ' (Hijri 1448, Shaban 10)'}<br />at <b>Srinivasa Mahal,</b> Vanjipalayam Road, Tirupur - 641 602.</p>
            <Divider />
            <p>Nikkah : 11.30 am onwards</p>
          </Card>

          <Card k="walima" label="Walima">
            <h3 className="script ctitle">Walima Invitation</h3>
            <p className="gap" style={{ letterSpacing: '.04em' }}>YOU ARE CORDIALLY INVITED TO WALIMA</p>
            <p className="script cname gap">S. Rohith Riyaz <span className="cs">B.Sc.(CSA),</span></p>
            <p className="cs">(Ranaco Moldwell Pvt. Ltd., Group of companies)</p>
            <p>S/o. Mr. S. Shajahan &amp; Mrs. S. Shahitha</p>
            <p className="gap">with</p>
            <p className="script cname">A. Aneesa Fathima <span className="cs">BBA.(CA), MBA</span></p>
            <p>D/o. Mr. M. Aslam &amp; Mrs. S. Abitha Begum</p>
            <p className="cs">(Peace Garments)</p>
            <p className="gap">On</p>
            <div className="datebox"><span>Wednesday</span><b>20</b><span>Jan’ 2027</span></div>
            <p>11.30 am to 3.00 pm</p>
            <p className="gap cs">~ Venue ~</p>
            <p className="cb">Aysha Mahal - Hall 1</p>
            <p>Palakkad Main Road, Kuniyamuthur, Coimbatore.</p>
          </Card>
        </div>
        <button className="btn" type="button" onClick={() => window.print()}>Print / Save as PDF</button>
      </section>

      <footer className="footer">
        <div className="footer-panel">
          <Crescent className="section-crescent" />
          <p className="footer-dua" lang="ar" dir="rtl">بَارَكَ اللَّهُ لَكُمَا وَبَارَكَ عَلَيْكُمَا وَجَمَعَ بَيْنَكُمَا فِي خَيْرٍ</p>
          <p className="footer-dua footer-translit">Barakallahu lakuma wa baraka alaikuma wa jama’a baynakuma fi khayr.</p>
          <p className="footer-thanks">Expecting your presence at our Nikkah and Walima</p>
          <div className="footer-events">
            <div><b>Nikkah</b><span>Sunday, 17 January 2027</span><span>11:30 AM onwards</span><span>Srinivasa Mahal, Tiruppur</span></div>
            <div><b>Walima</b><span>Wednesday, 20 January 2027</span><span>11:30 AM – 3:00 PM</span><span>Aysha Mahal – Hall 1, Coimbatore</span></div>
          </div>
          <p className="footer-names">S. Rohith Riyaz &amp; A. Aneesa Fathima</p>
          <p className="footer-thanks">Jazakumullahu khairan</p>
          <p className="footer-insha">Insha’Allah</p>
        </div>
      </footer>
    </div>
  )
}
